import React from "react";
import { useState } from "react";
import { useHistory } from "react-router-dom";
import "./style.css";

const User = () => {
  const [userName, setUserName] = useState("");

  const history = useHistory();
  const userNameF = (e) => {
    history.push(`/Description/${e.target.userNamee.value}`);
  };

  return (
    <div className="grand">
      <div className="userBox">
        <h1>Enter Your name</h1>
        <form 
        // onSubmit={userNameF}
        >
          <input
            id="textField"
            type="text"
            name="userName"
           
          />
         
            <button
              className="enterBtn"
              onClick={userNameF}
            >
              Enter
            </button>
          
        </form>
      </div>
    </div>
  );
};

export default User;